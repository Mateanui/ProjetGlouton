package glouton.vue;

public interface Observer {
	public void update();
}
