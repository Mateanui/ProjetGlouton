## Lancement de l'algorithme

# Exécuter la commande :

> java -jar projet_glouton.jar

> Exécuter la commande "java -jar nomFileJar.jar" ou lancer le fichier .sh "./launch.sh" (N'oubliez pas de faire un "chmod u+x launch.sh")

> Enclenché le boutton "Lancer" pour lancer l’algorithme glouton simple

> Vous pouvez sélectionner une autre instance via le boutton "Sélectionner"

> La saisie de texte qui est par défaut à 10, représente le nombre d’ordres aléatoires pour récupérer la solution optimale

>Pour activer cette algorithme glouton pour la solution optimale, on appuie sur le boutton "Solution ultime", et renvoie donc la meilleur des solutions sur la partie visuel de la grille. 

Si vous mettez 1000, cela peut prendre plusieurs secondes.
Il va donc falloir scroller dans le text pour avoir plus d’information sur les données utilisées.
