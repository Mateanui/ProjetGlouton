#!/bin/bash

java -jar projet_glouton.jar
